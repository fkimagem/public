var searchData=
[
  ['datum_0',['datum',['../struct_label_config.html#aff8f9f0c0ec295dffc185469ad49ac1e',1,'LabelConfig']]],
  ['default_5fspispeed_1',['DEFAULT_SPISPEED',['../class_x_p_t2046.html#a9076a6a1a23cf935b7d89fae0801a399',1,'XPT2046']]],
  ['defaultclickedid_2',['defaultClickedId',['../struct_radio_group_config.html#a42950cd421e58447bf4792ab9d9f0fea',1,'RadioGroupConfig']]]
];
