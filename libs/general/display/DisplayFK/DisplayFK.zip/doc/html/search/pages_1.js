var searchData=
[
  ['sugestões_20de_20melhorias_20para_20a_20biblioteca_20displayfk_0',['Sugestões de Melhorias para a Biblioteca DisplayFK',['../md__c____i_d_e_portable_arduino1_8_19_portable_sketchbook_libraries__display_f_k_update1.html',1,'']]]
];
