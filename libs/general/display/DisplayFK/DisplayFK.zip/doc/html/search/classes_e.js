var searchData=
[
  ['xpt2046_0',['XPT2046',['../class_x_p_t2046.html',1,'']]]
];
