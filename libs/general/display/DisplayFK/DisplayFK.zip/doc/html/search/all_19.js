var searchData=
[
  ['z_0',['z',['../class_x_p_t2046.html#aecb8c817497473fbc0e7c0e73022123b',1,'XPT2046']]]
];
