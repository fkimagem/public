var searchData=
[
  ['sd_0',['SD',['../wimage_8h.html#a5aecbe50d643b2a3b5d9d9ca665fd937a38f99abbc1d339c277c0669e7bc373c0',1,'wimage.h']]],
  ['spiffs_1',['SPIFFS',['../wimage_8h.html#a5aecbe50d643b2a3b5d9d9ca665fd937a146673cebceb52efdad49e33019dd764',1,'wimage.h']]]
];
