var searchData=
[
  ['enabletouchlog_0',['enableTouchLog',['../class_display_f_k.html#a07e3e9ec39f733dae344d273efd832a6',1,'DisplayFK']]],
  ['endtouchcommunication_1',['endTouchCommunication',['../class_x_p_t2046.html#a4aa0a13c0d0e5792f7d8d6656562a3f6',1,'XPT2046']]],
  ['externalkeyboard_2',['ExternalKeyboard',['../class_external_keyboard.html#accd637c315434efec3d4c8a41ed1312e',1,'ExternalKeyboard']]],
  ['extract_5fkeywords_3',['extract_keywords',['../namespacegen__keywords.html#afab8e96d9ca36335120c7b362b33a961',1,'gen_keywords']]]
];
