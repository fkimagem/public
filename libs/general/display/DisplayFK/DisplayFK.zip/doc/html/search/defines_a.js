var searchData=
[
  ['r_5fbaseline_0',['R_BASELINE',['../widgetsetup_8h.html#a0deee3f947ff8b137adef497be019e8f',1,'widgetsetup.h']]]
];
