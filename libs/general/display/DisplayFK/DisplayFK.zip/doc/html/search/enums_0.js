var searchData=
[
  ['callbackorigin_0',['CallbackOrigin',['../class_widget_base.html#afc5d8840ee8c89fdaf98d6901ee2ee05',1,'WidgetBase']]]
];
