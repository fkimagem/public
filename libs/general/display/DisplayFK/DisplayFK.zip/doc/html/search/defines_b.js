var searchData=
[
  ['spinbox_5fdebug_0',['SPINBOX_DEBUG',['../wspinbox_8cpp.html#adf1405a72c5ebbf4c97eb5bea813aa0e',1,'wspinbox.cpp']]]
];
