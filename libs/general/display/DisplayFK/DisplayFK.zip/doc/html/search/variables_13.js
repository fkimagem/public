var searchData=
[
  ['text_0',['text',['../struct_label_config.html#a055715273c1fc8f2eb0bcbf31df62ede',1,'LabelConfig::text()'],['../struct_text_button_config.html#a76eca8924db6ddbdce7009846455e39e',1,'TextButtonConfig::text()']]],
  ['textcolor_1',['textColor',['../struct_circular_bar_config.html#a9e0b006d72c708e8715380b078d6cda0',1,'CircularBarConfig::textColor()'],['../struct_gauge_config.html#aa9007603fde8e840567e0e8fa0009785',1,'GaugeConfig::textColor()'],['../struct_line_chart_config.html#a14d98c4359a1c96d7fbc485baa6eb2c6',1,'LineChartConfig::textColor()'],['../struct_spin_box_config.html#aa1a85699ac4a50c288282174e9fc44b8',1,'SpinBoxConfig::textColor()'],['../struct_text_button_config.html#a7e65931fb9d36f8095238f6a71be3123',1,'TextButtonConfig::textColor()'],['../struct_vertical_analog_config.html#a69b6b73448edcc02195f59c71d0e0020',1,'VerticalAnalogConfig::textColor()']]],
  ['thickness_2',['thickness',['../struct_circular_bar_config.html#a714a593c50de3a99d1f26c1e802d990e',1,'CircularBarConfig']]],
  ['title_3',['title',['../struct_gauge_config.html#a17641544e0fd70461131e9db0fe06f40',1,'GaugeConfig']]],
  ['titlecolor_4',['titleColor',['../struct_gauge_config.html#a51579068dc807e451c615d123785b088',1,'GaugeConfig']]],
  ['touchspi_5',['touchspi',['../class_x_p_t2046.html#a422e29bdeef1ec23c98708871152c510',1,'XPT2046']]]
];
