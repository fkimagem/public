var searchData=
[
  ['font_5fdigit_0',['FONT_DIGIT',['../widgetsetup_8h.html#ac81c935d99bfe7f219b9820f697adfdd',1,'widgetsetup.h']]],
  ['font_5froboto_1',['FONT_ROBOTO',['../widgetsetup_8h.html#ada6b589b3dbef428b0ccd4a92af2c131',1,'widgetsetup.h']]]
];
