var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvwxyz~",
  1: "cdeghiklnrstvwx",
  2: "g",
  3: "bcdfgnortwx",
  4: "abcdefghilnoprstuvwx~",
  5: "_abcdefghiklmnopqrstuvwxyz",
  6: "f",
  7: "cfkps",
  8: "abcdeilnrstu",
  9: "abcdfhlmnqrst",
  10: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Macros",
  10: "Pages"
};

