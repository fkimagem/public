var searchData=
[
  ['xpt2046_0',['XPT2046',['../class_x_p_t2046.html#a12a2f9ce950d6e56dc85d82416d1c16e',1,'XPT2046::XPT2046(uint8_t cs)'],['../class_x_p_t2046.html#a2b319fa5d901575ba343d771abcc92db',1,'XPT2046::XPT2046(uint8_t clk, uint8_t miso, uint8_t mosi, uint8_t cs)']]]
];
