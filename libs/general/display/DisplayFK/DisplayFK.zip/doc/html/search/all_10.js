var searchData=
[
  ['qtd_5fcache_0',['QTD_CACHE',['../_teclado_externo_8h.html#a12acdfe7cfdf5bacab03daa31ef83843',1,'TecladoExterno.h']]],
  ['qtd_5fleituras_1',['QTD_LEITURAS',['../_teclado_externo_8h.html#adddc095cebea50ff675f0e42316bbf2b',1,'TecladoExterno.h']]],
  ['qtdkeys_2',['qtdKeys',['../structkeypad_extern__t.html#a6c99569d2b904afe1d3ba4a4ba272be5',1,'keypadExtern_t']]]
];
