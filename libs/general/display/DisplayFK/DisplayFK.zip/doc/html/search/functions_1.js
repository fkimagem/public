var searchData=
[
  ['begin_0',['begin',['../class_x_p_t2046.html#a3175e30f8a407f46af0c32d28ce4cb29',1,'XPT2046']]],
  ['begintouchcommunication_1',['beginTouchCommunication',['../class_x_p_t2046.html#a5a2905590695b60013a028c3961160fd',1,'XPT2046']]],
  ['blendcolors_2',['blendColors',['../class_widget_base.html#a2cb752eaf84522bb36631e5e2ea421f5',1,'WidgetBase']]]
];
