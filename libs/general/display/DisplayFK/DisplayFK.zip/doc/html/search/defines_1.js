var searchData=
[
  ['bc_5fdatum_0',['BC_DATUM',['../widgetsetup_8h.html#a882a52131a92930c848d2f274921e3bf',1,'widgetsetup.h']]],
  ['bl_5fdatum_1',['BL_DATUM',['../widgetsetup_8h.html#a4ee36ba2273938a1db0500b0b71dcaea',1,'widgetsetup.h']]],
  ['br_5fdatum_2',['BR_DATUM',['../widgetsetup_8h.html#ae56faab3cba6c288ec7e4557839cc0f4',1,'widgetsetup.h']]]
];
