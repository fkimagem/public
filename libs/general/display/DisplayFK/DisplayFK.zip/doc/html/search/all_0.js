var searchData=
[
  ['_5fclk_0',['_clk',['../class_x_p_t2046.html#a17d733ba3190bac6845df777fdc5511c',1,'XPT2046']]],
  ['_5fcs_1',['_cs',['../class_x_p_t2046.html#a6460a0ddf40c43d88bb0916d44c4aa46',1,'XPT2046']]],
  ['_5fmiso_2',['_miso',['../class_x_p_t2046.html#aaf4750728d4ae0d2e1b27c0b6e8da0c1',1,'XPT2046']]],
  ['_5fmosi_3',['_mosi',['../class_x_p_t2046.html#a0a52d5af9ef66aa176c0327c1cbf0743',1,'XPT2046']]]
];
