var searchData=
[
  ['xpt2046_2ecpp_0',['XPT2046.cpp',['../_x_p_t2046_8cpp.html',1,'']]],
  ['xpt2046_2eh_1',['XPT2046.h',['../_x_p_t2046_8h.html',1,'']]]
];
