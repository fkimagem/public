var searchData=
[
  ['y_0',['y',['../struct_coord_point__t.html#a16f442bada8650a92c8511f6f845019e',1,'CoordPoint_t::y()'],['../struct_rect__t.html#ac01102d3d7bee1fdf9236187f95758c1',1,'Rect_t::y()'],['../struct_text_bound__t.html#ae698f5ab980da0f55d1c07445bfb903e',1,'TextBound_t::y()'],['../struct_screen_point__t.html#a2febb3b3c0cadde77893fe4c9c341659',1,'ScreenPoint_t::y()'],['../class_x_p_t2046.html#ac4b4ed8ee99b291163590fd93b27a56a',1,'XPT2046::y()'],['../structradio__t.html#a8af5a8b7dadc69a2705474bca4699252',1,'radio_t::y()']]],
  ['ypos_1',['yPos',['../class_widget_base.html#ac6449ab35ba3c8e893d6485b1630562a',1,'WidgetBase']]],
  ['yscreen_2',['yScreen',['../struct_calibration_point__t.html#adaa809cebd8afbd017dc412201a3514f',1,'CalibrationPoint_t']]],
  ['ytouch_3',['yTouch',['../struct_calibration_point__t.html#a16f6b54b126b8373dbc6d0933842b7e2',1,'CalibrationPoint_t']]]
];
