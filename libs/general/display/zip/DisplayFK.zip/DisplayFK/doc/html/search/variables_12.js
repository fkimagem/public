var searchData=
[
  ['screen_0',['screen',['../class_widget_base.html#ab857f21de1dbcd279c763d46bea23d47',1,'WidgetBase']]],
  ['screenheight_1',['screenHeight',['../class_widget_base.html#ad6f4a969c42306301f9ae0f23149f148',1,'WidgetBase']]],
  ['screenwidth_2',['screenWidth',['../class_widget_base.html#ab821dc9c6ddf1cc9388ef79ec1c90183',1,'WidgetBase']]],
  ['sdcardok_3',['sdcardOK',['../class_display_f_k.html#a906f821e380cde6509c9f4229178786f',1,'DisplayFK']]],
  ['showinglog_4',['showingLog',['../class_widget_base.html#a220f8e75d0060fdc5fafaec4a7b4f4e4',1,'WidgetBase']]],
  ['showlabels_5',['showLabels',['../struct_gauge_config.html#a7dde9068d86b2f159cf4d2b217c52848',1,'GaugeConfig']]],
  ['showvalue_6',['showValue',['../struct_circular_bar_config.html#a4446379a7ac982ab5c3c83591fbf7917',1,'CircularBarConfig']]],
  ['showzeroline_7',['showZeroLine',['../struct_line_chart_config.html#a7787b0fd0934d2d1cfcdcf5bc1f573b9',1,'LineChartConfig']]],
  ['size_8',['size',['../struct_check_box_config.html#a364ed35e40b7e2c417ed15096e9cfbc7',1,'CheckBoxConfig']]],
  ['source_9',['source',['../struct_image_from_file_config.html#a16c3779aceeeb3f03df861e3d5cbfce5',1,'ImageFromFileConfig']]],
  ['startangle_10',['startAngle',['../struct_circular_bar_config.html#ac128ec458d93ab0a659e2bba485ad394',1,'CircularBarConfig']]],
  ['startvalue_11',['startValue',['../struct_input_external_config.html#a5e7f66a0c83e00b191de7ab6c47e015c',1,'InputExternalConfig::startValue()'],['../struct_number_box_config.html#a0b48f96ca545eb87adccaad755078eee',1,'NumberBoxConfig::startValue()'],['../struct_spin_box_config.html#ad38a6ed2b9caf6a7f9a122d41596de40',1,'SpinBoxConfig::startValue()'],['../struct_text_box_config.html#a026c472622542692c3a8d26a7f780861',1,'TextBoxConfig::startValue()']]],
  ['step_12',['step',['../struct_spin_box_config.html#a5283dcd54219d5cf6f7c33cc6df1612f',1,'SpinBoxConfig']]],
  ['steps_13',['steps',['../struct_vertical_analog_config.html#ae47987859f901edd22bcf056fa55f950',1,'VerticalAnalogConfig']]],
  ['suffix_14',['suffix',['../struct_label_config.html#a3ac3cca3582d563677fb72f7716cfa1a',1,'LabelConfig']]]
];
