var searchData=
[
  ['return_0',['RETURN',['../class_numpad.html#a9f3f5c04ce834507996fac1b95cd3caeaa2bec276a54439fe011eb523b845dac5',1,'Numpad::RETURN()'],['../class_w_keyboard.html#a2b9465cea20ffecc439ce856842f7950aa2bec276a54439fe011eb523b845dac5',1,'WKeyboard::RETURN()']]]
];
