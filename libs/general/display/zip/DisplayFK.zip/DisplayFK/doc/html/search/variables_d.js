var searchData=
[
  ['needlecolor_0',['needleColor',['../struct_gauge_config.html#a940e5d386aabeaab7d40af4de458e5fb',1,'GaugeConfig']]]
];
