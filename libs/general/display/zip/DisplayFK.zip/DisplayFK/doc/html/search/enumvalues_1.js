var searchData=
[
  ['bold_0',['BOLD',['../base_types_8h.html#a72082b59a51886b2606c8c0be2f84684a2909dd0e0336f10b6da9735b859a3d19',1,'baseTypes.h']]]
];
