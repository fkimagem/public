var searchData=
[
  ['touch_0',['TOUCH',['../class_widget_base.html#afc5d8840ee8c89fdaf98d6901ee2ee05a2b40a1ea27beb450618885ec87f0ee15',1,'WidgetBase']]]
];
