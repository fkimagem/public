var searchData=
[
  ['l_5fbaseline_0',['L_BASELINE',['../widgetsetup_8h.html#ac3075bcd6a9916ded3f9fe301c10b1ab',1,'widgetsetup.h']]],
  ['log_5flength_1',['LOG_LENGTH',['../displayfk_8h.html#abcf5ff60910276a3c6aba858e6e96a02',1,'displayfk.h']]],
  ['log_5fmax_5fsize_2',['LOG_MAX_SIZE',['../displayfk_8h.html#ae890bbd431aa7d19fcbe247502ce3feb',1,'displayfk.h']]],
  ['logxpt_3',['LOGXPT',['../_x_p_t2046_8h.html#a0a4f22ffe84ca4ca06bf2e5541936c8b',1,'XPT2046.h']]]
];
