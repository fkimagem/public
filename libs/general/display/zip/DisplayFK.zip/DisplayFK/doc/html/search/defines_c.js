var searchData=
[
  ['tc_5fdatum_0',['TC_DATUM',['../widgetsetup_8h.html#a88855d5e62c7b3ee2c16ee2006e1638e',1,'widgetsetup.h']]],
  ['timeout_5fclick_1',['TIMEOUT_CLICK',['../base_types_8h.html#a5ebad099caa3c1ad0283c09c4488d10b',1,'baseTypes.h']]],
  ['tl_5fdatum_2',['TL_DATUM',['../widgetsetup_8h.html#ab5e3647e20719a695e2557fad717b54a',1,'widgetsetup.h']]],
  ['tr_5fdatum_3',['TR_DATUM',['../widgetsetup_8h.html#add267d7a315077bbc47f2dfe149fa163',1,'widgetsetup.h']]]
];
