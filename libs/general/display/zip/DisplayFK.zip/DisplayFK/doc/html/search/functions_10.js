var searchData=
[
  ['updatefont_0',['updateFont',['../class_widget_base.html#a685bdf04c94ef540804da7d07ef170ff',1,'WidgetBase']]]
];
