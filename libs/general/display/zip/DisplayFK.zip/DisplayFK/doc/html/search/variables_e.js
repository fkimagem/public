var searchData=
[
  ['oldvalue_0',['oldValue',['../struct_line_chart_value__t.html#a03c6070bbf0b7c9a791c1dcbf0556a4d',1,'LineChartValue_t']]]
];
