var searchData=
[
  ['x_0',['x',['../struct_coord_point__t.html#a70639f1d922326798692ae9b0ac3e689',1,'CoordPoint_t::x()'],['../struct_rect__t.html#a9bf759dd2d33be713a5d09f684b864a5',1,'Rect_t::x()'],['../struct_text_bound__t.html#a84eb416d9e0d468c2a47c67f914d6217',1,'TextBound_t::x()'],['../struct_screen_point__t.html#a15b6ad1454dba256da54a1c755755b25',1,'ScreenPoint_t::x()'],['../class_x_p_t2046.html#a0ab4dff42a783be45c430e3865109920',1,'XPT2046::x()'],['../structradio__t.html#a12a3aab6c5d2e1a08c1dda177544364e',1,'radio_t::x()']]],
  ['xfilacallback_1',['xFilaCallback',['../class_widget_base.html#ac3b3a4e18c9158eb2bb315f79e947fb7',1,'WidgetBase']]],
  ['xpos_2',['xPos',['../class_widget_base.html#ae25d37afb78caf68139839b8fe2740b1',1,'WidgetBase']]],
  ['xpt2046_5fspispeed_3',['XPT2046_SPISPEED',['../class_x_p_t2046.html#af290bfd96091c78c48a3e0ed554812cc',1,'XPT2046']]],
  ['xpt2046_5fzlimit_4',['XPT2046_ZLIMIT',['../class_x_p_t2046.html#a3f26fd9c93d9646ddbb103bb5169912e',1,'XPT2046']]],
  ['xscreen_5',['xScreen',['../struct_calibration_point__t.html#aadcaa330c1a5ce64933782b91ead5828',1,'CalibrationPoint_t']]],
  ['xtouch_6',['xTouch',['../struct_calibration_point__t.html#adf5174b214a4be87541e958f51351bcb',1,'CalibrationPoint_t']]]
];
