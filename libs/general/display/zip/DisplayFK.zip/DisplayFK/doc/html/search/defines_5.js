var searchData=
[
  ['helpers_0',['HELPERS',['../widgetbase_8h.html#afd0e26a22bd84938857b2f67be8433db',1,'widgetbase.h']]]
];
