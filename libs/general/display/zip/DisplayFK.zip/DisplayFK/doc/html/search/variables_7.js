var searchData=
[
  ['gridcolor_0',['gridColor',['../struct_line_chart_config.html#aea583dac9755a5ec24417a6cd5f9b8be',1,'LineChartConfig']]],
  ['group_1',['group',['../struct_radio_group_config.html#ac962ce6ba1928c209eefe0aedddd32d3',1,'RadioGroupConfig']]]
];
