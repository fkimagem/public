var searchData=
[
  ['ncols_0',['NCOLS',['../numpad_8h.html#aafffdbebac459e968e0f6ac2f50832b3',1,'numpad.h']]],
  ['nrows_1',['NROWS',['../numpad_8h.html#ad1b201a53819ee0b206811f261d9dfce',1,'numpad.h']]]
];
