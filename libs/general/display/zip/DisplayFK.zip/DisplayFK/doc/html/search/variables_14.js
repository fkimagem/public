var searchData=
[
  ['ultimaleitura_0',['ultimaLeitura',['../structkeypad_extern__t.html#a91ee256d9f709d88ddf7436f5ce31084',1,'keypadExtern_t']]],
  ['usingkeyboard_1',['usingKeyboard',['../class_widget_base.html#af87da2f755677b5e2feea6ad2ce94ee6',1,'WidgetBase']]]
];
