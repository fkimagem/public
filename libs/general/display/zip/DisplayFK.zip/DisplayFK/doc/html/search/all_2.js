var searchData=
[
  ['backgroundcolor_0',['backgroundColor',['../struct_circular_bar_config.html#a02b228148f79025327bc28d86766e6cc',1,'CircularBarConfig::backgroundColor()'],['../struct_input_external_config.html#a41f792af69e00b76fbf5ae4e6821051d',1,'InputExternalConfig::backgroundColor()'],['../struct_gauge_config.html#aff23199c2927d652066ed4f0fc4c9018',1,'GaugeConfig::backgroundColor()'],['../struct_label_config.html#a855d437fd2137dd9f69aeda4b23fb2f0',1,'LabelConfig::backgroundColor()'],['../struct_line_chart_config.html#a83cf65aec347b29ef5a334b163a3a03c',1,'LineChartConfig::backgroundColor()'],['../struct_number_box_config.html#a0ecd92b2485a0a3edea9831657153f65',1,'NumberBoxConfig::backgroundColor()'],['../struct_text_box_config.html#afb7f8c04e08458df5b4b4ce78c3c6372',1,'TextBoxConfig::backgroundColor()'],['../struct_text_button_config.html#a84a2b6e4bbe14f7994886da0820f9205',1,'TextButtonConfig::backgroundColor()'],['../struct_vertical_analog_config.html#acd47e4515dccf560c0085ff4e1bb2e69',1,'VerticalAnalogConfig::backgroundColor()'],['../class_widget_base.html#a77a9f894591cb7871282cd5868a36a15',1,'WidgetBase::backgroundColor()']]],
  ['basetypes_2eh_1',['baseTypes.h',['../base_types_8h.html',1,'']]],
  ['bc_5fdatum_2',['BC_DATUM',['../widgetsetup_8h.html#a882a52131a92930c848d2f274921e3bf',1,'widgetsetup.h']]],
  ['begin_3',['begin',['../class_x_p_t2046.html#a3175e30f8a407f46af0c32d28ce4cb29',1,'XPT2046']]],
  ['begintouchcommunication_4',['beginTouchCommunication',['../class_x_p_t2046.html#a5a2905590695b60013a028c3961160fd',1,'XPT2046']]],
  ['bl_5fdatum_5',['BL_DATUM',['../widgetsetup_8h.html#a4ee36ba2273938a1db0500b0b71dcaea',1,'widgetsetup.h']]],
  ['blendcolors_6',['blendColors',['../class_widget_base.html#a2cb752eaf84522bb36631e5e2ea421f5',1,'WidgetBase']]],
  ['bold_7',['BOLD',['../base_types_8h.html#a72082b59a51886b2606c8c0be2f84684a2909dd0e0336f10b6da9735b859a3d19',1,'baseTypes.h']]],
  ['bordercolor_8',['borderColor',['../struct_gauge_config.html#a41d1d163a869c1844d656b436ccde6a5',1,'GaugeConfig::borderColor()'],['../struct_line_chart_config.html#ae4cf69ac8c5fcb4e0fbe21182a09a95f',1,'LineChartConfig::borderColor()'],['../struct_vertical_analog_config.html#a531a63fc2e320a765951c83810ba56a6',1,'VerticalAnalogConfig::borderColor()']]],
  ['br_5fdatum_9',['BR_DATUM',['../widgetsetup_8h.html#ae56faab3cba6c288ec7e4557839cc0f4',1,'widgetsetup.h']]],
  ['buttons_10',['buttons',['../struct_radio_group_config.html#a5a426b291dec25cb99aa93bb5b8da235',1,'RadioGroupConfig']]]
];
